export class ConfigCtrl {
}

ConfigCtrl.templateUrl = 'datasource/config.html';
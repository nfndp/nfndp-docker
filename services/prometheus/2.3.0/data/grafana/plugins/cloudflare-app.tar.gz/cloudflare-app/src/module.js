import {ConfigCtrl} from './config/config.js';
import {loadPluginCss} from 'app/plugins/sdk';

export {
  ConfigCtrl
};

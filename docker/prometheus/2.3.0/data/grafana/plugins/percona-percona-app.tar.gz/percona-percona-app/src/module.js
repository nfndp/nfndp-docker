import {PerconaAppConfigCtrl} from './components/config';

export {
  PerconaAppConfigCtrl as ConfigCtrl
};
